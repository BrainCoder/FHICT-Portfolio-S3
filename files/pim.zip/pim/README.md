# Showcase-PIM

## API Docs

https://documenter.getpostman.com/view/5851190/TVzLnfEN

## Start Using

gradle bootRun

## ToDo
- [ ] Testing
- [ ] Algoritm
- [ ] React frontend?
