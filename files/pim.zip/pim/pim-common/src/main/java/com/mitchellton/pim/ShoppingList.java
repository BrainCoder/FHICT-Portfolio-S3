package com.mitchellton.pim;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ShoppingList extends ArrayList<ShoppingListItem> {

    public ShoppingList newInstance(){
        return new ShoppingList();
    }

    public void add(PartDo partDo, int amount, List<PriceDo> priceList) {
        this.add(new ShoppingListItem(partDo, amount, priceList));
    }

}
