package com.mitchellton.pim;

import java.util.UUID;

public interface Do {

    UUID getId();

}
