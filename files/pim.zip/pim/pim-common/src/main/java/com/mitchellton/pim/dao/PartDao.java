package com.mitchellton.pim.dao;

import com.mitchellton.pim.PartDo;

public interface PartDao extends Dao<PartDo> {

}
