package com.mitchellton.pim.dao;

import com.mitchellton.pim.DistributorDo;

public interface DistributorDao extends Dao<DistributorDo> {

}
