package com.mitchellton.pim.dao;

import com.mitchellton.pim.BillOfMaterialsDo;

public interface BillOfMaterialsDao extends Dao<BillOfMaterialsDo> {

}