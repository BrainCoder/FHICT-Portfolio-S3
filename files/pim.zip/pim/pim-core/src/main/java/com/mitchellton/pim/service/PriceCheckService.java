package com.mitchellton.pim.service;

import com.mitchellton.pim.*;
import com.mitchellton.pim.dao.BillOfMaterialsDao;
import com.mitchellton.pim.dao.BillOfMaterialsItemDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toSet;

@Service
public class PriceCheckService {

    BillOfMaterialsService billOfMaterialsService;
    PriceService priceService;
    PartService partService;
    ShoppingList shoppingListType;

    @Autowired
    public PriceCheckService(BillOfMaterialsService billOfMaterialsService, PriceService priceService, PartService partService, ShoppingList shoppingList) {
        this.billOfMaterialsService = billOfMaterialsService;
        this.priceService = priceService;
        this.partService = partService;
        this.shoppingListType = shoppingList;
    }

    public ShoppingList getShoppingList(UUID bomUUID)
    {
        var shoppingList = shoppingListType.newInstance();
        var bom = billOfMaterialsService.getById(bomUUID);

        bom.get().getBomItems().forEach(item -> {
            List<PriceDo> priceList = priceService.getCheapestPrices(item.getPartId(), item.getAmount());
            shoppingList.add(partService.getById(item.getPartId(), false).get(), item.getAmount(), priceList);
        });
        return shoppingList;
    }

    public Map<UUID, ShoppingList> getShoppingListByDistributor(UUID bomUUID) {
        Map<UUID, ShoppingList> shoppingListsByDistributor = new HashMap<>();
        ShoppingList shoppingList = getShoppingList(bomUUID);

        shoppingList.forEach(item -> {
            if (item.getPrices().size() > 0)
                return;

            UUID distributorId = item.getPrices().get(0).getDistributorId();

            if (!shoppingListsByDistributor.containsKey(distributorId)) {
                ShoppingList list = shoppingListType.newInstance();
                shoppingListsByDistributor.put(distributorId, list);
            }
            shoppingListsByDistributor.get(distributorId).add(item);
        });

        return shoppingListsByDistributor;
    }
}
