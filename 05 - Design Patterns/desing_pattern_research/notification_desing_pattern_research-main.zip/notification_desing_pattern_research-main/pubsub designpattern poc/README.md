# pubsub_designpattern_poc
A POC for pub-sub design pattern
