package designpattern.pattern;

public class Message {
    String message;

    public Message(String message) {
        this.message = message;
    }
}