package mitchellton.observerexample.observer;

public interface Observer {

    void update(String message);

}
