# Observer design pattern POC
A POC for observer design pattern